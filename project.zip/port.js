// Code By Webdevtrick ( https://webdevtrick.com )
function beforeAfter() {
  document.getElementById('compare').style.width = document.getElementById('slider').value + "%";
}